# Magic Book Datapack
---
Minecraftの制作中ワールド**Magic Book**のリソースパックです
